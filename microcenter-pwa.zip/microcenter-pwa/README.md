# 🖥️ Microcenter PWA — Guia de Deploy

## O que é este projeto?
Aplicativo web progressivo (PWA) da Microcenter para acompanhamento de serviços de manutenção.
Funciona como app instalável no celular sem passar pelas lojas.

---

## 📦 Estrutura de arquivos

```
microcenter-pwa/
├── index.html              ← Página principal
├── package.json            ← Dependências
├── vite.config.js          ← Configuração do bundler
├── vercel.json             ← Configuração de deploy
├── src/
│   ├── main.jsx            ← Entrada do React
│   └── App.jsx             ← Aplicativo completo
└── public/
    ├── manifest.json       ← Configuração PWA
    ├── sw.js               ← Service Worker (offline)
    └── icons/              ← Ícones do app (todos os tamanhos)
```

---

## 🚀 Deploy na Vercel (GRATUITO) — Passo a passo

### Pré-requisitos
- Conta no [GitHub](https://github.com) (gratuita)
- Conta na [Vercel](https://vercel.com) (gratuita)

### Passo 1 — Subir o código no GitHub

1. Acesse https://github.com/new e crie um repositório chamado `microcenter`
2. No seu computador, instale o [Git](https://git-scm.com/downloads) se não tiver
3. Abra o terminal na pasta `microcenter-pwa` e execute:

```bash
git init
git add .
git commit -m "Microcenter PWA inicial"
git branch -M main
git remote add origin https://github.com/SEU_USUARIO/microcenter.git
git push -u origin main
```

### Passo 2 — Conectar na Vercel

1. Acesse https://vercel.com e faça login com sua conta GitHub
2. Clique em **"Add New Project"**
3. Selecione o repositório `microcenter`
4. Em **Framework Preset**, selecione **Vite**
5. Clique em **Deploy**

✅ Pronto! Em ~2 minutos seu app estará online em um link como:
`https://microcenter.vercel.app`

---

## 📲 Como o cliente instala no celular

### Android (Chrome)
1. O cliente acessa o link no Chrome
2. Aparece automaticamente um banner **"Adicionar à tela inicial"**
3. Ou vai em Menu (⋮) → **"Adicionar à tela inicial"**
4. O ícone da Microcenter aparece na tela como um app normal

### iPhone (Safari)
1. O cliente abre o link no Safari
2. Toca no botão **Compartilhar** (quadrado com seta)
3. Rola e toca em **"Adicionar à Tela de Início"**
4. Toca em **"Adicionar"**

---

## 🔐 Credenciais padrão

| Tipo | Campo | Valor |
|------|-------|-------|
| Admin | E-mail | admin@microcenter.com |
| Admin | Senha | admin123 |
| Cliente | Código | Gerado pelo admin |

> **⚠️ Importante:** Troque a senha do admin após o primeiro acesso!
> Para isso, edite o arquivo `src/App.jsx` e altere o campo `password` no `SEED_USERS`.

---

## 🔄 Como atualizar o app depois

Sempre que fizer mudanças:
```bash
git add .
git commit -m "descrição da mudança"
git push
```
A Vercel faz o redeploy automaticamente em segundos!

---

## 💡 Dicas

- O app funciona **offline** após a primeira visita (service worker)
- Os dados ficam salvos no armazenamento local do dispositivo
- Para usar em múltiplos dispositivos com dados sincronizados, seria necessário adicionar um banco de dados (ex: Firebase) — me peça ajuda se quiser isso!
