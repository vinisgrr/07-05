import { useState, useEffect } from "react";

// ─── Persistent Storage Helpers ───────────────────────────────────────────────
async function loadData(key) {
  try {
    const res = await window.storage.get(key);
    return res ? JSON.parse(res.value) : null;
  } catch {
    return null;
  }
}
async function saveData(key, value) {
  try {
    await window.storage.set(key, JSON.stringify(value));
  } catch {}
}

// ─── Initial seed data ────────────────────────────────────────────────────────
const SEED_USERS = [
  { id: "admin", name: "Administrador", email: "admin@microcenter.com", password: "admin123", role: "admin" },
];
const SEED_TICKETS = [];

// ─── Status config ────────────────────────────────────────────────────────────
const STATUS = {
  aguardando_avaliacao: { label: "Aguardando Avaliação", color: "#F59E0B", icon: "⏳" },
  em_manutencao:        { label: "Em Manutenção",        color: "#3B82F6", icon: "🔧" },
  aguardando_peca:      { label: "Aguardando Peça",      color: "#8B5CF6", icon: "📦" },
  pronto:               { label: "Pronto p/ Retirada",   color: "#10B981", icon: "✅" },
  entregue:             { label: "Entregue",             color: "#6B7280", icon: "🏠" },
};

// ─── Utilities ────────────────────────────────────────────────────────────────
function formatDate(iso) {
  return new Date(iso).toLocaleString("pt-BR", { day: "2-digit", month: "2-digit", year: "numeric", hour: "2-digit", minute: "2-digit" });
}
function genId() {
  return "MC" + Date.now().toString(36).toUpperCase();
}

// ─── CSS ──────────────────────────────────────────────────────────────────────
const css = `
  @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=DM+Sans:wght@300;400;500&display=swap');

  *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

  :root {
    --bg: #0A0A0F;
    --surface: #111118;
    --surface2: #1A1A24;
    --border: #2A2A38;
    --accent: #00E5FF;
    --accent2: #FF6B35;
    --text: #F0F0F8;
    --muted: #6B6B88;
    --font-head: 'Syne', sans-serif;
    --font-body: 'DM Sans', sans-serif;
  }

  body { background: var(--bg); color: var(--text); font-family: var(--font-body); }

  .app { min-height: 100vh; display: flex; flex-direction: column; }

  /* ── NAV ── */
  .nav {
    display: flex; align-items: center; justify-content: space-between;
    padding: 0 2rem; height: 64px;
    background: var(--surface);
    border-bottom: 1px solid var(--border);
    position: sticky; top: 0; z-index: 100;
  }
  .nav-logo {
    font-family: var(--font-head); font-weight: 800; font-size: 1.3rem;
    display: flex; align-items: center; gap: .5rem;
    letter-spacing: -.02em;
  }
  .nav-logo span { color: var(--accent); }
  .nav-user { display: flex; align-items: center; gap: 1rem; }
  .badge-role {
    font-size: .7rem; font-weight: 600; letter-spacing: .08em; text-transform: uppercase;
    padding: 3px 10px; border-radius: 20px;
    background: color-mix(in srgb, var(--accent) 15%, transparent);
    color: var(--accent); border: 1px solid color-mix(in srgb, var(--accent) 30%, transparent);
  }
  .btn-logout {
    background: none; border: 1px solid var(--border); color: var(--muted);
    padding: 6px 14px; border-radius: 8px; cursor: pointer; font-size: .85rem;
    font-family: var(--font-body); transition: all .2s;
  }
  .btn-logout:hover { border-color: var(--accent2); color: var(--accent2); }

  /* ── LOGIN ── */
  .login-wrap {
    flex: 1; display: flex; align-items: center; justify-content: center;
    background: var(--bg);
    background-image: radial-gradient(ellipse 60% 40% at 50% 0%, color-mix(in srgb, var(--accent) 8%, transparent), transparent);
    padding: 2rem;
  }
  .login-card {
    width: 100%; max-width: 420px;
    background: var(--surface); border: 1px solid var(--border);
    border-radius: 20px; padding: 2.5rem;
    box-shadow: 0 40px 80px rgba(0,0,0,.5);
  }
  .login-logo {
    font-family: var(--font-head); font-weight: 800; font-size: 2rem;
    text-align: center; margin-bottom: .25rem; letter-spacing: -.03em;
  }
  .login-logo span { color: var(--accent); }
  .login-sub { text-align: center; color: var(--muted); margin-bottom: 2rem; font-size: .9rem; }
  .tabs { display: flex; gap: .5rem; margin-bottom: 1.5rem; background: var(--bg); border-radius: 10px; padding: 4px; }
  .tab { flex: 1; padding: 8px; border: none; border-radius: 8px; cursor: pointer; font-family: var(--font-body); font-size: .85rem; font-weight: 500; transition: all .2s; background: none; color: var(--muted); }
  .tab.active { background: var(--surface2); color: var(--text); }

  /* ── FORM ELEMENTS ── */
  .field { margin-bottom: 1rem; }
  .field label { display: block; font-size: .8rem; font-weight: 500; color: var(--muted); margin-bottom: 6px; text-transform: uppercase; letter-spacing: .06em; }
  .field input, .field select, .field textarea {
    width: 100%; background: var(--bg); border: 1px solid var(--border);
    color: var(--text); padding: 10px 14px; border-radius: 10px;
    font-family: var(--font-body); font-size: .9rem; outline: none;
    transition: border-color .2s;
  }
  .field input:focus, .field select:focus, .field textarea:focus { border-color: var(--accent); }
  .field textarea { resize: vertical; min-height: 80px; }
  .field select option { background: var(--surface2); }

  .btn-primary {
    width: 100%; padding: 12px; background: var(--accent); color: #000;
    border: none; border-radius: 10px; font-weight: 700; font-size: .95rem;
    font-family: var(--font-head); cursor: pointer; transition: opacity .2s;
    letter-spacing: .02em;
  }
  .btn-primary:hover { opacity: .85; }
  .btn-primary:disabled { opacity: .4; cursor: default; }
  .btn-secondary {
    padding: 8px 16px; background: var(--surface2); color: var(--text);
    border: 1px solid var(--border); border-radius: 8px; font-family: var(--font-body);
    font-size: .85rem; cursor: pointer; transition: all .2s;
  }
  .btn-secondary:hover { border-color: var(--accent); color: var(--accent); }
  .btn-danger {
    padding: 8px 16px; background: none; color: #F87171;
    border: 1px solid #F8717140; border-radius: 8px; font-family: var(--font-body);
    font-size: .85rem; cursor: pointer; transition: all .2s;
  }
  .btn-danger:hover { background: #F8717120; }

  .error-msg { color: #F87171; font-size: .82rem; margin-top: .5rem; text-align: center; }

  /* ── LAYOUT ── */
  .main { flex: 1; padding: 2rem; max-width: 1200px; margin: 0 auto; width: 100%; }

  .page-header { margin-bottom: 2rem; }
  .page-header h1 { font-family: var(--font-head); font-size: 1.8rem; font-weight: 800; letter-spacing: -.03em; }
  .page-header p { color: var(--muted); margin-top: .25rem; font-size: .9rem; }

  /* ── ADMIN TABS ── */
  .admin-tabs { display: flex; gap: .5rem; margin-bottom: 2rem; border-bottom: 1px solid var(--border); padding-bottom: 0; }
  .admin-tab { padding: 10px 20px; background: none; border: none; border-bottom: 2px solid transparent; color: var(--muted); font-family: var(--font-head); font-weight: 600; font-size: .9rem; cursor: pointer; transition: all .2s; margin-bottom: -1px; }
  .admin-tab.active { color: var(--accent); border-bottom-color: var(--accent); }

  /* ── CARDS ── */
  .card { background: var(--surface); border: 1px solid var(--border); border-radius: 16px; padding: 1.5rem; }
  .card + .card { margin-top: 1rem; }

  .grid-2 { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; }
  @media(max-width: 700px) { .grid-2 { grid-template-columns: 1fr; } }

  /* ── TICKET CARD ── */
  .ticket-card {
    background: var(--surface); border: 1px solid var(--border);
    border-radius: 16px; padding: 1.5rem; margin-bottom: 1rem;
    border-left: 4px solid;
    transition: transform .2s;
  }
  .ticket-card:hover { transform: translateY(-2px); }
  .ticket-header { display: flex; align-items: flex-start; justify-content: space-between; gap: 1rem; flex-wrap: wrap; }
  .ticket-id { font-family: var(--font-head); font-size: .75rem; font-weight: 700; color: var(--muted); letter-spacing: .1em; }
  .ticket-device { font-family: var(--font-head); font-weight: 700; font-size: 1.1rem; margin: .25rem 0; }
  .ticket-client { font-size: .85rem; color: var(--muted); }
  .status-badge {
    display: inline-flex; align-items: center; gap: .4rem;
    padding: 5px 12px; border-radius: 20px; font-size: .78rem; font-weight: 600;
    white-space: nowrap;
  }
  .ticket-body { margin-top: 1rem; }
  .ticket-desc { font-size: .88rem; color: var(--muted); line-height: 1.6; }
  .ticket-meta { display: flex; gap: 1.5rem; margin-top: 1rem; flex-wrap: wrap; }
  .ticket-meta span { font-size: .78rem; color: var(--muted); }
  .ticket-meta strong { color: var(--text); }

  .ticket-actions { display: flex; gap: .5rem; margin-top: 1.25rem; flex-wrap: wrap; }

  /* ── HISTORY ── */
  .history { margin-top: 1.25rem; border-top: 1px solid var(--border); padding-top: 1rem; }
  .history-title { font-size: .75rem; text-transform: uppercase; letter-spacing: .08em; color: var(--muted); font-weight: 600; margin-bottom: .75rem; }
  .history-item { display: flex; gap: .75rem; margin-bottom: .6rem; }
  .history-dot { width: 8px; height: 8px; border-radius: 50%; margin-top: 5px; flex-shrink: 0; }
  .history-text { font-size: .82rem; }
  .history-text .h-status { font-weight: 600; }
  .history-text .h-date { color: var(--muted); font-size: .76rem; margin-top: 1px; }
  .history-text .h-note { color: var(--muted); font-style: italic; font-size: .8rem; }

  /* ── USERS TABLE ── */
  .table-wrap { overflow-x: auto; }
  table { width: 100%; border-collapse: collapse; font-size: .88rem; }
  th { text-align: left; padding: 10px 14px; color: var(--muted); font-size: .75rem; text-transform: uppercase; letter-spacing: .07em; font-weight: 600; border-bottom: 1px solid var(--border); }
  td { padding: 12px 14px; border-bottom: 1px solid var(--border); }
  tr:last-child td { border-bottom: none; }
  tr:hover td { background: var(--surface2); }

  /* ── STATS ── */
  .stats { display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 1rem; margin-bottom: 2rem; }
  .stat-card { background: var(--surface); border: 1px solid var(--border); border-radius: 14px; padding: 1.25rem; }
  .stat-num { font-family: var(--font-head); font-size: 2.2rem; font-weight: 800; }
  .stat-label { font-size: .78rem; color: var(--muted); margin-top: .25rem; }

  /* ── MODAL ── */
  .modal-bg { position: fixed; inset: 0; background: rgba(0,0,0,.7); display: flex; align-items: center; justify-content: center; z-index: 999; padding: 1rem; }
  .modal { background: var(--surface); border: 1px solid var(--border); border-radius: 20px; padding: 2rem; width: 100%; max-width: 500px; max-height: 90vh; overflow-y: auto; }
  .modal h2 { font-family: var(--font-head); font-weight: 800; font-size: 1.3rem; margin-bottom: 1.5rem; letter-spacing: -.02em; }
  .modal-footer { display: flex; gap: .75rem; justify-content: flex-end; margin-top: 1.5rem; }

  /* ── CLIENT VIEW ── */
  .client-hero {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 20px; padding: 2rem; margin-bottom: 2rem;
    background-image: radial-gradient(ellipse 80% 60% at 100% 0%, color-mix(in srgb, var(--accent) 6%, transparent), transparent);
  }
  .client-hero h2 { font-family: var(--font-head); font-size: 1.4rem; font-weight: 800; }
  .client-hero p { color: var(--muted); margin-top: .25rem; }
  .big-status {
    display: inline-flex; align-items: center; gap: .6rem;
    padding: 10px 22px; border-radius: 30px; font-size: 1rem; font-weight: 700;
    margin-top: 1rem; font-family: var(--font-head);
  }

  /* ── EMPTY STATE ── */
  .empty { text-align: center; padding: 4rem 2rem; color: var(--muted); }
  .empty-icon { font-size: 3rem; margin-bottom: 1rem; }
  .empty p { font-size: .9rem; }

  /* ── SEARCH ── */
  .search-bar { display: flex; gap: .75rem; margin-bottom: 1.5rem; flex-wrap: wrap; }
  .search-bar input { flex: 1; min-width: 200px; }

  /* ── NOTE UPDATE ── */
  .note-area { margin-top: .75rem; }
`;

// ─── App ──────────────────────────────────────────────────────────────────────
export default function App() {
  const [users, setUsers]     = useState(null);
  const [tickets, setTickets] = useState(null);
  const [session, setSession] = useState(null);
  const [loading, setLoading] = useState(true);

  // Load from storage
  useEffect(() => {
    (async () => {
      const u = await loadData("mc_users");
      const t = await loadData("mc_tickets");
      setUsers(u || SEED_USERS);
      setTickets(t || SEED_TICKETS);
      setLoading(false);
    })();
  }, []);

  // Persist users
  useEffect(() => { if (users !== null) saveData("mc_users", users); }, [users]);
  useEffect(() => { if (tickets !== null) saveData("mc_tickets", tickets); }, [tickets]);

  if (loading) return (
    <>
      <style>{css}</style>
      <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100vh", fontFamily: "var(--font-head)", color: "var(--accent)", fontSize: "1.1rem" }}>
        Carregando Microcenter…
      </div>
    </>
  );

  return (
    <>
      <style>{css}</style>
      <div className="app">
        {session ? (
          <>
            <Nav session={session} onLogout={() => setSession(null)} />
            {session.role === "admin"
              ? <AdminPanel users={users} setUsers={setUsers} tickets={tickets} setTickets={setTickets} session={session} />
              : <ClientPanel session={session} tickets={tickets} />
            }
          </>
        ) : (
          <LoginScreen users={users} onLogin={setSession} />
        )}
      </div>
    </>
  );
}

// ─── Nav ──────────────────────────────────────────────────────────────────────
function Nav({ session, onLogout }) {
  return (
    <nav className="nav">
      <div className="nav-logo">
        🖥️ Micro<span>center</span>
      </div>
      <div className="nav-user">
        <span style={{ fontSize: ".88rem" }}>{session.name}</span>
        <span className="badge-role">{session.role === "admin" ? "Admin" : "Cliente"}</span>
        <button className="btn-logout" onClick={onLogout}>Sair</button>
      </div>
    </nav>
  );
}

// ─── Login ────────────────────────────────────────────────────────────────────
function LoginScreen({ users, onLogin }) {
  const [tab, setTab]         = useState("client");
  const [email, setEmail]     = useState("");
  const [password, setPassword] = useState("");
  const [code, setCode]       = useState("");
  const [error, setError]     = useState("");

  function handleLogin() {
    setError("");
    if (tab === "admin") {
      const u = users.find(u => u.role === "admin" && u.email === email && u.password === password);
      if (!u) return setError("E-mail ou senha inválidos.");
      onLogin(u);
    } else {
      const u = users.find(u => u.role === "client" && u.code === code);
      if (!u) return setError("Código de acesso inválido.");
      onLogin(u);
    }
  }

  return (
    <div className="login-wrap">
      <div className="login-card">
        <div className="login-logo">Micro<span>center</span></div>
        <p className="login-sub">Sistema de Acompanhamento de Serviços</p>

        <div className="tabs">
          <button className={`tab ${tab === "client" ? "active" : ""}`} onClick={() => { setTab("client"); setError(""); }}>👤 Cliente</button>
          <button className={`tab ${tab === "admin" ? "active" : ""}`} onClick={() => { setTab("admin"); setError(""); }}>🔧 Administrador</button>
        </div>

        {tab === "admin" ? (
          <>
            <div className="field"><label>E-mail</label><input value={email} onChange={e => setEmail(e.target.value)} placeholder="admin@microcenter.com" /></div>
            <div className="field"><label>Senha</label><input type="password" value={password} onChange={e => setPassword(e.target.value)} placeholder="••••••••" onKeyDown={e => e.key === "Enter" && handleLogin()} /></div>
          </>
        ) : (
          <div className="field">
            <label>Código de Acesso</label>
            <input value={code} onChange={e => setCode(e.target.value.toUpperCase())} placeholder="Ex: MC-ABC123" onKeyDown={e => e.key === "Enter" && handleLogin()} style={{ letterSpacing: ".1em", fontWeight: 600, fontSize: "1rem" }} />
            <div style={{ fontSize: ".78rem", color: "var(--muted)", marginTop: ".4rem" }}>Digite o código fornecido pela Microcenter</div>
          </div>
        )}

        {error && <div className="error-msg">{error}</div>}
        <button className="btn-primary" style={{ marginTop: "1rem" }} onClick={handleLogin}>Entrar</button>
      </div>
    </div>
  );
}

// ─── Admin Panel ──────────────────────────────────────────────────────────────
function AdminPanel({ users, setUsers, tickets, setTickets, session }) {
  const [tab, setTab] = useState("tickets");

  return (
    <div className="main">
      <div className="page-header">
        <h1>Painel Administrativo</h1>
        <p>Gerencie chamados e clientes da Microcenter</p>
      </div>

      <StatsBar tickets={tickets} />

      <div className="admin-tabs">
        {[["tickets","🗂️ Chamados"],["users","👥 Clientes"],["new_ticket","➕ Novo Chamado"],["new_user","👤 Novo Cliente"]].map(([k,l]) => (
          <button key={k} className={`admin-tab ${tab === k ? "active" : ""}`} onClick={() => setTab(k)}>{l}</button>
        ))}
      </div>

      {tab === "tickets"    && <TicketList tickets={tickets} setTickets={setTickets} users={users} adminMode />}
      {tab === "users"      && <UserList users={users} setUsers={setUsers} tickets={tickets} />}
      {tab === "new_ticket" && <NewTicketForm users={users} setTickets={setTickets} onDone={() => setTab("tickets")} />}
      {tab === "new_user"   && <NewUserForm setUsers={setUsers} onDone={() => setTab("users")} />}
    </div>
  );
}

function StatsBar({ tickets }) {
  const counts = Object.keys(STATUS).reduce((a, k) => ({ ...a, [k]: tickets.filter(t => t.status === k).length }), {});
  return (
    <div className="stats">
      <div className="stat-card"><div className="stat-num">{tickets.length}</div><div className="stat-label">Total de Chamados</div></div>
      <div className="stat-card"><div className="stat-num" style={{ color: STATUS.em_manutencao.color }}>{counts.em_manutencao}</div><div className="stat-label">Em Manutenção</div></div>
      <div className="stat-card"><div className="stat-num" style={{ color: STATUS.aguardando_peca.color }}>{counts.aguardando_peca}</div><div className="stat-label">Aguard. Peça</div></div>
      <div className="stat-card"><div className="stat-num" style={{ color: STATUS.pronto.color }}>{counts.pronto}</div><div className="stat-label">Prontos</div></div>
    </div>
  );
}

// ─── Ticket List ──────────────────────────────────────────────────────────────
function TicketList({ tickets, setTickets, users, adminMode }) {
  const [search, setSearch]   = useState("");
  const [filter, setFilter]   = useState("all");
  const [editId, setEditId]   = useState(null);

  const filtered = tickets.filter(t => {
    const q = search.toLowerCase();
    const matchQ = !q || t.device.toLowerCase().includes(q) || t.id.toLowerCase().includes(q) || (t.clientName||"").toLowerCase().includes(q);
    const matchF = filter === "all" || t.status === filter;
    return matchQ && matchF;
  }).sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  function updateTicket(id, changes) {
    setTickets(prev => prev.map(t => t.id === id ? { ...t, ...changes } : t));
  }

  return (
    <div>
      <div className="search-bar">
        <div className="field" style={{ flex: 1, marginBottom: 0 }}>
          <input value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar por dispositivo, ID ou cliente…" />
        </div>
        <div className="field" style={{ marginBottom: 0 }}>
          <select value={filter} onChange={e => setFilter(e.target.value)}>
            <option value="all">Todos os status</option>
            {Object.entries(STATUS).map(([k, v]) => <option key={k} value={k}>{v.label}</option>)}
          </select>
        </div>
      </div>

      {filtered.length === 0 && (
        <div className="empty"><div className="empty-icon">🗂️</div><p>Nenhum chamado encontrado.</p></div>
      )}

      {filtered.map(t => (
        <TicketCard key={t.id} ticket={t} users={users} adminMode={adminMode}
          onUpdate={changes => updateTicket(t.id, changes)}
          expanded={editId === t.id} onToggle={() => setEditId(editId === t.id ? null : t.id)}
        />
      ))}
    </div>
  );
}

function TicketCard({ ticket: t, users, adminMode, onUpdate, expanded, onToggle }) {
  const s = STATUS[t.status];
  const [newStatus, setNewStatus] = useState(t.status);
  const [note, setNote]           = useState("");

  function applyUpdate() {
    const entry = { status: newStatus, date: new Date().toISOString(), note: note.trim() };
    onUpdate({
      status: newStatus,
      history: [...(t.history || []), entry],
    });
    setNote("");
    onToggle();
  }

  return (
    <div className="ticket-card" style={{ borderLeftColor: s.color }}>
      <div className="ticket-header">
        <div>
          <div className="ticket-id">#{t.id}</div>
          <div className="ticket-device">{t.device}</div>
          {adminMode && <div className="ticket-client">👤 {t.clientName}</div>}
        </div>
        <div className="status-badge" style={{ background: s.color + "22", color: s.color, border: `1px solid ${s.color}44` }}>
          {s.icon} {s.label}
        </div>
      </div>
      <div className="ticket-body">
        <div className="ticket-desc">{t.description}</div>
        <div className="ticket-meta">
          <span>📅 Abertura: <strong>{formatDate(t.createdAt)}</strong></span>
          {t.budget && <span>💰 Orçamento: <strong>R$ {t.budget}</strong></span>}
          {t.technician && <span>🔧 Técnico: <strong>{t.technician}</strong></span>}
        </div>
      </div>

      {adminMode && (
        <div className="ticket-actions">
          <button className="btn-secondary" onClick={onToggle}>{expanded ? "Fechar" : "✏️ Atualizar Status"}</button>
        </div>
      )}

      {adminMode && expanded && (
        <div style={{ marginTop: "1.25rem", padding: "1.25rem", background: "var(--bg)", borderRadius: "12px", border: "1px solid var(--border)" }}>
          <div className="field">
            <label>Novo Status</label>
            <select value={newStatus} onChange={e => setNewStatus(e.target.value)}>
              {Object.entries(STATUS).map(([k, v]) => <option key={k} value={k}>{v.icon} {v.label}</option>)}
            </select>
          </div>
          <div className="field">
            <label>Observação (opcional)</label>
            <textarea value={note} onChange={e => setNote(e.target.value)} placeholder="Ex: Peça chegará em 3 dias úteis…" rows={2} />
          </div>
          <div style={{ display: "flex", gap: ".75rem" }}>
            <button className="btn-primary" style={{ width: "auto", padding: "10px 22px" }} onClick={applyUpdate}>Salvar</button>
            <button className="btn-secondary" onClick={onToggle}>Cancelar</button>
          </div>
        </div>
      )}

      {t.history && t.history.length > 0 && (
        <div className="history">
          <div className="history-title">📋 Histórico de atualizações</div>
          {t.history.map((h, i) => {
            const hs = STATUS[h.status];
            return (
              <div key={i} className="history-item">
                <div className="history-dot" style={{ background: hs?.color || "var(--muted)" }} />
                <div className="history-text">
                  <div className="h-status" style={{ color: hs?.color }}>{hs?.icon} {hs?.label}</div>
                  {h.note && <div className="h-note">"{h.note}"</div>}
                  <div className="h-date">{formatDate(h.date)}</div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}

// ─── New Ticket ───────────────────────────────────────────────────────────────
function NewTicketForm({ users, setTickets, onDone }) {
  const clients = users.filter(u => u.role === "client");
  const [form, setForm] = useState({ clientId: "", device: "", description: "", technician: "", budget: "" });
  const [err, setErr] = useState("");

  function set(k, v) { setForm(f => ({ ...f, [k]: v })); }

  function submit() {
    if (!form.clientId || !form.device || !form.description) return setErr("Preencha cliente, dispositivo e descrição.");
    const client = clients.find(c => c.id === form.clientId);
    const ticket = {
      id: genId(), clientId: form.clientId, clientName: client.name,
      device: form.device, description: form.description,
      technician: form.technician, budget: form.budget,
      status: "aguardando_avaliacao", createdAt: new Date().toISOString(),
      history: [{ status: "aguardando_avaliacao", date: new Date().toISOString(), note: "Chamado aberto." }],
    };
    setTickets(prev => [ticket, ...prev]);
    onDone();
  }

  return (
    <div className="card" style={{ maxWidth: 600 }}>
      <h2 style={{ fontFamily: "var(--font-head)", fontWeight: 800, marginBottom: "1.5rem" }}>Abrir Novo Chamado</h2>
      {clients.length === 0 && <div className="error-msg" style={{ marginBottom: "1rem" }}>⚠️ Nenhum cliente cadastrado ainda.</div>}
      <div className="field">
        <label>Cliente</label>
        <select value={form.clientId} onChange={e => set("clientId", e.target.value)}>
          <option value="">Selecionar cliente…</option>
          {clients.map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
        </select>
      </div>
      <div className="field"><label>Dispositivo</label><input value={form.device} onChange={e => set("device", e.target.value)} placeholder="Ex: Notebook Dell Inspiron 15" /></div>
      <div className="field"><label>Descrição do Problema</label><textarea value={form.description} onChange={e => set("description", e.target.value)} placeholder="Descreva o problema relatado pelo cliente…" /></div>
      <div className="grid-2">
        <div className="field"><label>Técnico Responsável</label><input value={form.technician} onChange={e => set("technician", e.target.value)} placeholder="Nome do técnico" /></div>
        <div className="field"><label>Orçamento (R$)</label><input value={form.budget} onChange={e => set("budget", e.target.value)} placeholder="0,00" /></div>
      </div>
      {err && <div className="error-msg">{err}</div>}
      <div style={{ display: "flex", gap: ".75rem", marginTop: ".5rem" }}>
        <button className="btn-primary" style={{ width: "auto", padding: "11px 28px" }} onClick={submit}>Abrir Chamado</button>
        <button className="btn-secondary" onClick={onDone}>Cancelar</button>
      </div>
    </div>
  );
}

// ─── User List ────────────────────────────────────────────────────────────────
function UserList({ users, setUsers, tickets }) {
  const clients = users.filter(u => u.role === "client");

  function removeUser(id) {
    if (!confirm("Remover este cliente?")) return;
    setUsers(prev => prev.filter(u => u.id !== id));
  }

  return (
    <div>
      {clients.length === 0 ? (
        <div className="empty"><div className="empty-icon">👥</div><p>Nenhum cliente cadastrado ainda.<br/>Use a aba "Novo Cliente" para adicionar.</p></div>
      ) : (
        <div className="card">
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th>Nome</th>
                  <th>Telefone</th>
                  <th>Código de Acesso</th>
                  <th>Chamados</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {clients.map(c => {
                  const userTickets = tickets.filter(t => t.clientId === c.id);
                  return (
                    <tr key={c.id}>
                      <td><strong>{c.name}</strong></td>
                      <td style={{ color: "var(--muted)" }}>{c.phone || "—"}</td>
                      <td>
                        <span style={{ fontFamily: "monospace", background: "var(--bg)", padding: "3px 10px", borderRadius: "6px", fontSize: ".85rem", letterSpacing: ".05em", color: "var(--accent)" }}>
                          {c.code}
                        </span>
                      </td>
                      <td>{userTickets.length}</td>
                      <td><button className="btn-danger" onClick={() => removeUser(c.id)}>Remover</button></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
}

// ─── New User ─────────────────────────────────────────────────────────────────
function NewUserForm({ setUsers, onDone }) {
  const [form, setForm] = useState({ name: "", phone: "" });
  const [created, setCreated] = useState(null);
  const [err, setErr] = useState("");

  function set(k, v) { setForm(f => ({ ...f, [k]: v })); }

  function submit() {
    if (!form.name.trim()) return setErr("Informe o nome do cliente.");
    const code = "MC-" + Math.random().toString(36).substring(2, 8).toUpperCase();
    const user = { id: "cli_" + Date.now(), name: form.name.trim(), phone: form.phone, code, role: "client" };
    setUsers(prev => [...prev, user]);
    setCreated(user);
  }

  if (created) return (
    <div className="card" style={{ maxWidth: 480, textAlign: "center" }}>
      <div style={{ fontSize: "3rem", marginBottom: "1rem" }}>✅</div>
      <h2 style={{ fontFamily: "var(--font-head)", fontWeight: 800, marginBottom: ".5rem" }}>Cliente Cadastrado!</h2>
      <p style={{ color: "var(--muted)", marginBottom: "1.5rem" }}>Compartilhe o código abaixo com <strong>{created.name}</strong>:</p>
      <div style={{ background: "var(--bg)", border: "2px dashed var(--accent)", borderRadius: "14px", padding: "1.5rem", marginBottom: "1.5rem" }}>
        <div style={{ fontSize: ".8rem", color: "var(--muted)", marginBottom: ".5rem", textTransform: "uppercase", letterSpacing: ".08em" }}>Código de Acesso</div>
        <div style={{ fontFamily: "var(--font-head)", fontSize: "2rem", fontWeight: 800, color: "var(--accent)", letterSpacing: ".1em" }}>{created.code}</div>
      </div>
      <div style={{ display: "flex", gap: ".75rem", justifyContent: "center" }}>
        <button className="btn-primary" style={{ width: "auto", padding: "10px 24px" }} onClick={() => { setCreated(null); setForm({ name: "", phone: "" }); }}>Cadastrar Outro</button>
        <button className="btn-secondary" onClick={onDone}>Ir para Clientes</button>
      </div>
    </div>
  );

  return (
    <div className="card" style={{ maxWidth: 480 }}>
      <h2 style={{ fontFamily: "var(--font-head)", fontWeight: 800, marginBottom: "1.5rem" }}>Novo Cliente</h2>
      <div className="field"><label>Nome Completo</label><input value={form.name} onChange={e => set("name", e.target.value)} placeholder="João da Silva" /></div>
      <div className="field"><label>Telefone (opcional)</label><input value={form.phone} onChange={e => set("phone", e.target.value)} placeholder="(11) 99999-9999" /></div>
      {err && <div className="error-msg">{err}</div>}
      <div style={{ display: "flex", gap: ".75rem", marginTop: ".5rem" }}>
        <button className="btn-primary" style={{ width: "auto", padding: "11px 28px" }} onClick={submit}>Gerar Código</button>
        <button className="btn-secondary" onClick={onDone}>Cancelar</button>
      </div>
    </div>
  );
}

// ─── Client Panel ─────────────────────────────────────────────────────────────
function ClientPanel({ session, tickets }) {
  const myTickets = tickets.filter(t => t.clientId === session.id)
    .sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));

  return (
    <div className="main">
      <div className="client-hero">
        <h2>Olá, {session.name.split(" ")[0]}! 👋</h2>
        <p>Acompanhe o status dos seus equipamentos em manutenção</p>
      </div>

      {myTickets.length === 0 ? (
        <div className="empty"><div className="empty-icon">🖥️</div><p>Nenhum chamado aberto no momento.<br/>Quando seu equipamento chegar, ele aparecerá aqui.</p></div>
      ) : (
        myTickets.map(t => (
          <ClientTicketCard key={t.id} ticket={t} />
        ))
      )}
    </div>
  );
}

function ClientTicketCard({ ticket: t }) {
  const s = STATUS[t.status];
  return (
    <div className="ticket-card" style={{ borderLeftColor: s.color, marginBottom: "1.5rem" }}>
      <div className="ticket-header">
        <div>
          <div className="ticket-id">#{t.id}</div>
          <div className="ticket-device">{t.device}</div>
        </div>
      </div>

      <div className="big-status" style={{ background: s.color + "22", color: s.color, border: `1px solid ${s.color}44` }}>
        <span style={{ fontSize: "1.3rem" }}>{s.icon}</span>
        {s.label}
      </div>

      <div className="ticket-body">
        <div className="ticket-desc" style={{ marginTop: "1rem" }}><strong>Problema relatado:</strong> {t.description}</div>
        <div className="ticket-meta">
          <span>📅 Abertura: <strong>{formatDate(t.createdAt)}</strong></span>
          {t.budget && <span>💰 Orçamento: <strong>R$ {t.budget}</strong></span>}
          {t.technician && <span>🔧 Técnico: <strong>{t.technician}</strong></span>}
        </div>
      </div>

      {t.history && t.history.length > 0 && (
        <div className="history">
          <div className="history-title">📋 Atualizações</div>
          {[...t.history].reverse().map((h, i) => {
            const hs = STATUS[h.status];
            return (
              <div key={i} className="history-item">
                <div className="history-dot" style={{ background: hs?.color || "var(--muted)" }} />
                <div className="history-text">
                  <div className="h-status" style={{ color: hs?.color }}>{hs?.icon} {hs?.label}</div>
                  {h.note && <div className="h-note">"{h.note}"</div>}
                  <div className="h-date">{formatDate(h.date)}</div>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
